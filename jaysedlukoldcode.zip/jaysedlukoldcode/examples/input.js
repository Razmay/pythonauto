loop();

function loop() {
    console.log('Spam Kappa 123');
    setTimeout(loop, 100);
}
