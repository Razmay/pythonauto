// My Twitter keys
// From https://apps.twitter.com/app/5771872/keys
exports.API_KEY      = 'klb5ZwXFj33b62Y9w1tDlRvzX';
exports.API_SECRET   = 'sVfj69b6L0O3XTFwRI58cYV0HROPyhG2UrUJcrlF9yulsglrXI';
exports.TOKEN        = '48435578-FJfE3ohMRA5xyuAO9RScy1ZBzjBK6OPS6n3Hs3mhb';
exports.TOKEN_SECRET = 'Rvd8gyo8IONsaQuJlW01eiagcFEJEL7wVvSeUCOK9FwR4';
